import pandas as pd
import pandas_profiling
df = pd.read_excel('Netflix.xlsx')
pandas_profiling.ProfileReport(df)
lang = input()
a = df.loc[df['Language'] == lang]
print('total'+lang+'movies are '+str(len(a)))
print('percentage of'+lang+'are '+str((len(a)/len(df))*100))