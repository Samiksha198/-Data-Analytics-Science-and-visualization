import pandas as pd
import pandas_profiling
df=pd.read_excel('Netflix.xlsx')
pandas_profiling.ProfileReport(df)
b=df[df['IMDB Score']>7]
c=df[df['IMDB Score']<4]
print("hit movies",len(b),"percentage is: ",(len(b)/len(df))*100)
print("flop movies",len(c),"percentage is: ",(len(c)/len(df))*100)