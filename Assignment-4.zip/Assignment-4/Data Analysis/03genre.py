import pandas as pd
import pandas_profiling
df=pd.read_excel('Netflix.xlsx')
pandas_profiling.ProfileReport(df)
gen=input()
e=df[df['Genre']==gen]
e
print('movies in',gen,': ',e['Title'].count())
hits=e[e['IMDB Score']>7]
flops=e[e['IMDB Score']<4]
print('hits in',gen,':',len(hits),'percentage: ',(len(hits)/len(df))*100)
print('flops in',gen,':',len(flops),'percentage: ',(len(flops)/len(df))*100)