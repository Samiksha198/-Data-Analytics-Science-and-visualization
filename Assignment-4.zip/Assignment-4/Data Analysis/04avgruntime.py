import pandas as pd
import pandas_profiling
df = pd.read_excel('Netflix.xlsx')
pandas_profiling.ProfileReport(df)
b=df[df['IMDB Score']>7]
c=df[df['IMDB Score']<4]
print('avg run time of hit movies',(b['Runtime'].sum())/len(b))
print('avg run time of flop movies',(c['Runtime'].sum())/len(c))