import pandas as pd
import pandas_profiling
df = pd.read_excel('Netflix.xlsx')
pandas_profiling.ProfileReport(df)
cou=df['Language'].value_counts()
d=dict()
for i in df['Language'].unique():
  d[i]=len(df[df['Language']==i])
d