import pandas as pd
import pandas_profiling
df=pd.read_excel('Netflix.xlsx')
pandas_profiling.ProfileReport(df)
c=['a','b','c','d','e','f','g','h','i','j']
j=['se','sse','jse','hr','m','e','pm','sa','ja','w']
a=[1,2,3,4,5,6,7,8,9,10]
d={'company':c,'jobs':j,'avgsalary':a}
df=pd.DataFrame(d)
df
df.to_csv('file.csv')