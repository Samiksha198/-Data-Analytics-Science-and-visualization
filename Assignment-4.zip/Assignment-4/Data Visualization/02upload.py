import pandas as pd
import pandas_profiling
df=pd.read_excel('Netflix.xlsx')
pandas_profiling.ProfileReport(df)
pwd()
df=pd.read_csv('/content/drive/MyDrive/file.csv')
df