import matplotlib.pyplot as plt
import numpy as np
x=np.array(df['company'])
y=np.array(df['avgsalary'])
plt.plot(x,y)