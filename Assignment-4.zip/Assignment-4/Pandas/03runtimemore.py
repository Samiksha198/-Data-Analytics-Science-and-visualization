import pandas as pd
import pandas_profiling
df=pd.read_excel('Netflix.xlsx')
pandas_profiling.ProfileReport(df)
m=df[df['Runtime']>125]
m['Title']