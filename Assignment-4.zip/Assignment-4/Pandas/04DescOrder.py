import pandas as pd
import pandas_profiling
df=pd.read_excel('Netflix.xlsx')
pandas_profiling.ProfileReport(df)
df.sort_values("IMDB Score",axis=0,ascending=False,inplace=True)
df['Title'].head(10)